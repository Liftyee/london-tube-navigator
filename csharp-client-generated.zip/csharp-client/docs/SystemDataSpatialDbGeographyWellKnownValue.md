# IO.Swagger.Model.SystemDataSpatialDbGeographyWellKnownValue
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CoordinateSystemId** | **int?** |  | [optional] 
**WellKnownText** | **string** |  | [optional] 
**WellKnownBinary** | **byte[]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

