# IO.Swagger.Model.TflApiCommonApiVersionInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Label** | **string** |  | [optional] 
**Timestamp** | **DateTime?** |  | [optional] 
**Version** | **string** |  | [optional] 
**Assemblies** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

