# IO.Swagger.Model.TflApiCommonGeoPoint
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Lat** | **double?** |  | 
**Lon** | **double?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

