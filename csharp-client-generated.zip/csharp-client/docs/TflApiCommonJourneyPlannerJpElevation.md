# IO.Swagger.Model.TflApiCommonJourneyPlannerJpElevation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Distance** | **int?** |  | [optional] 
**StartLat** | **double?** |  | [optional] 
**StartLon** | **double?** |  | [optional] 
**EndLat** | **double?** |  | [optional] 
**EndLon** | **double?** |  | [optional] 
**HeightFromPreviousPoint** | **int?** |  | [optional] 
**Gradient** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

