# IO.Swagger.Model.TflApiCommonPlaceGeo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SwLat** | **double?** |  | [optional] 
**SwLon** | **double?** |  | [optional] 
**NeLat** | **double?** |  | [optional] 
**NeLon** | **double?** |  | [optional] 
**Lat** | **double?** |  | [optional] 
**Lon** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

