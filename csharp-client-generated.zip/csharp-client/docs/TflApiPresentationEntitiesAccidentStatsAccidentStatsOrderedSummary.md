# IO.Swagger.Model.TflApiPresentationEntitiesAccidentStatsAccidentStatsOrderedSummary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Year** | **int?** |  | [optional] 
**Borough** | **string** |  | [optional] 
**Accidents** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

