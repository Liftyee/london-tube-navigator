# IO.Swagger.Model.TflApiPresentationEntitiesAccidentStatsCasualty
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Age** | **int?** |  | [optional] 
**Class** | **string** |  | [optional] 
**Severity** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 
**AgeBand** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

