# IO.Swagger.Model.TflApiPresentationEntitiesAdditionalProperties
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Category** | **string** |  | [optional] 
**Key** | **string** |  | [optional] 
**SourceSystemKey** | **string** |  | [optional] 
**Value** | **string** |  | [optional] 
**Modified** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

