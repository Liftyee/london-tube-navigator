# IO.Swagger.Model.TflApiPresentationEntitiesBay
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BayType** | **string** |  | [optional] 
**BayCount** | **int?** |  | [optional] 
**Free** | **int?** |  | [optional] 
**Occupied** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

