# IO.Swagger.Model.TflApiPresentationEntitiesCarParkOccupancy
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] 
**Bays** | [**List&lt;TflApiPresentationEntitiesBay&gt;**](TflApiPresentationEntitiesBay.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**CarParkDetailsUrl** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

