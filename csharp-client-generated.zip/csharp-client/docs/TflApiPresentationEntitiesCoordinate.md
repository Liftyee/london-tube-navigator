# IO.Swagger.Model.TflApiPresentationEntitiesCoordinate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Longitude** | **double?** |  | [optional] 
**Latitude** | **double?** |  | [optional] 
**Easting** | **double?** |  | [optional] 
**Northing** | **double?** |  | [optional] 
**XCoord** | **int?** |  | [optional] 
**YCoord** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

