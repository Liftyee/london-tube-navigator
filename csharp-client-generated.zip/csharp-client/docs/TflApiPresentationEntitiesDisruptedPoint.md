# IO.Swagger.Model.TflApiPresentationEntitiesDisruptedPoint
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AtcoCode** | **string** |  | [optional] 
**FromDate** | **DateTime?** |  | [optional] 
**ToDate** | **DateTime?** |  | [optional] 
**Description** | **string** |  | [optional] 
**CommonName** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 
**StationAtcoCode** | **string** |  | [optional] 
**Appearance** | **string** |  | [optional] 
**AdditionalInformation** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

