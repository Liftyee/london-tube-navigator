# IO.Swagger.Model.TflApiPresentationEntitiesFaresFare
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | [optional] 
**PassengerType** | **string** |  | [optional] 
**ValidFrom** | **DateTime?** |  | [optional] 
**ValidUntil** | **DateTime?** |  | [optional] 
**TicketTime** | **string** |  | [optional] 
**TicketType** | **string** |  | [optional] 
**Cost** | **string** |  | [optional] 
**Cap** | **double?** |  | [optional] 
**Description** | **string** |  | [optional] 
**Zone** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

