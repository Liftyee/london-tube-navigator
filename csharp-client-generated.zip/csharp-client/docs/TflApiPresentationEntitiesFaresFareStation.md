# IO.Swagger.Model.TflApiPresentationEntitiesFaresFareStation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AtcoCode** | **string** |  | [optional] 
**CommonName** | **string** |  | [optional] 
**FareCategory** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

