# IO.Swagger.Model.TflApiPresentationEntitiesFaresFaresPeriod
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | [optional] 
**StartDate** | **DateTime?** |  | [optional] 
**ViewableDate** | **DateTime?** |  | [optional] 
**EndDate** | **DateTime?** |  | [optional] 
**IsFuture** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

