# IO.Swagger.Model.TflApiPresentationEntitiesFaresFaresSection
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Header** | **string** |  | [optional] 
**Index** | **int?** |  | [optional] 
**Journey** | [**TflApiPresentationEntitiesFaresJourney**](TflApiPresentationEntitiesFaresJourney.md) |  | [optional] 
**Rows** | [**List&lt;TflApiPresentationEntitiesFaresFareDetails&gt;**](TflApiPresentationEntitiesFaresFareDetails.md) |  | [optional] 
**Messages** | [**List&lt;TflApiPresentationEntitiesMessage&gt;**](TflApiPresentationEntitiesMessage.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

