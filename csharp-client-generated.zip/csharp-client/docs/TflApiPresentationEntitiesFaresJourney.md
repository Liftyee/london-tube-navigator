# IO.Swagger.Model.TflApiPresentationEntitiesFaresJourney
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FromStation** | [**TflApiPresentationEntitiesFaresFareStation**](TflApiPresentationEntitiesFaresFareStation.md) |  | [optional] 
**ToStation** | [**TflApiPresentationEntitiesFaresFareStation**](TflApiPresentationEntitiesFaresFareStation.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

