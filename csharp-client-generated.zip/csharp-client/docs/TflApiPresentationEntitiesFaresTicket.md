# IO.Swagger.Model.TflApiPresentationEntitiesFaresTicket
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PassengerType** | **string** |  | [optional] 
**TicketType** | [**TflApiPresentationEntitiesFaresTicketType**](TflApiPresentationEntitiesFaresTicketType.md) |  | [optional] 
**TicketTime** | [**TflApiPresentationEntitiesFaresTicketTime**](TflApiPresentationEntitiesFaresTicketTime.md) |  | [optional] 
**Cost** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 
**DisplayOrder** | **int?** |  | [optional] 
**Messages** | [**List&lt;TflApiPresentationEntitiesMessage&gt;**](TflApiPresentationEntitiesMessage.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

