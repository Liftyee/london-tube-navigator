# IO.Swagger.Model.TflApiPresentationEntitiesIdentifier
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Uri** | **string** |  | [optional] 
**FullName** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**Crowding** | [**TflApiPresentationEntitiesCrowding**](TflApiPresentationEntitiesCrowding.md) |  | [optional] 
**RouteType** | **string** |  | [optional] 
**Status** | **string** |  | [optional] 
**MotType** | **string** |  | [optional] 
**Network** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

