# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerFareTap
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AtcoCode** | **string** |  | [optional] 
**TapDetails** | [**TflApiPresentationEntitiesJourneyPlannerFareTapDetails**](TflApiPresentationEntitiesJourneyPlannerFareTapDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

