# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerFareTapDetails
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ModeType** | **string** |  | [optional] 
**ValidationType** | **string** |  | [optional] 
**HostDeviceType** | **string** |  | [optional] 
**BusRouteId** | **string** |  | [optional] 
**NationalLocationCode** | **int?** |  | [optional] 
**TapTimestamp** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

