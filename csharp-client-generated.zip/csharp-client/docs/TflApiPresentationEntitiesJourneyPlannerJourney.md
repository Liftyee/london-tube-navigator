# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerJourney
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDateTime** | **DateTime?** |  | [optional] 
**Duration** | **int?** |  | [optional] 
**ArrivalDateTime** | **DateTime?** |  | [optional] 
**Description** | **string** |  | [optional] 
**AlternativeRoute** | **bool?** |  | [optional] 
**Legs** | [**List&lt;TflApiPresentationEntitiesJourneyPlannerLeg&gt;**](TflApiPresentationEntitiesJourneyPlannerLeg.md) |  | [optional] 
**Fare** | [**TflApiPresentationEntitiesJourneyPlannerJourneyFare**](TflApiPresentationEntitiesJourneyPlannerJourneyFare.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

