# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerJourneyFare
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalCost** | **int?** |  | [optional] 
**Fares** | [**List&lt;TflApiPresentationEntitiesJourneyPlannerFare&gt;**](TflApiPresentationEntitiesJourneyPlannerFare.md) |  | [optional] 
**Caveats** | [**List&lt;TflApiPresentationEntitiesJourneyPlannerFareCaveat&gt;**](TflApiPresentationEntitiesJourneyPlannerFareCaveat.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

