# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerJourneyPlannerCycleHireDockingStationData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OriginNumberOfBikes** | **int?** |  | [optional] 
**DestinationNumberOfBikes** | **int?** |  | [optional] 
**OriginNumberOfEmptySlots** | **int?** |  | [optional] 
**DestinationNumberOfEmptySlots** | **int?** |  | [optional] 
**OriginId** | **string** |  | [optional] 
**DestinationId** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

