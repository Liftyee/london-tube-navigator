# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerJourneyVector
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**From** | **string** |  | [optional] 
**To** | **string** |  | [optional] 
**Via** | **string** |  | [optional] 
**Uri** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

