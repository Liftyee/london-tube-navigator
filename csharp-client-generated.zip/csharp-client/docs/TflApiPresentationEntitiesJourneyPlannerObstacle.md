# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerObstacle
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **string** |  | [optional] 
**Incline** | **string** |  | [optional] 
**StopId** | **int?** |  | [optional] 
**Position** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

