# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerPath
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LineString** | **string** |  | [optional] 
**StopPoints** | [**List&lt;TflApiPresentationEntitiesIdentifier&gt;**](TflApiPresentationEntitiesIdentifier.md) |  | [optional] 
**Elevation** | [**List&lt;TflApiCommonJourneyPlannerJpElevation&gt;**](TflApiCommonJourneyPlannerJpElevation.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

