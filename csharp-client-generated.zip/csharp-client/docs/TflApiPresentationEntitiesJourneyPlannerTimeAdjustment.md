# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerTimeAdjustment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Date** | **string** |  | [optional] 
**Time** | **string** |  | [optional] 
**TimeIs** | **string** |  | [optional] 
**Uri** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

