# IO.Swagger.Model.TflApiPresentationEntitiesJourneyPlannerTimeAdjustments
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Earliest** | [**TflApiPresentationEntitiesJourneyPlannerTimeAdjustment**](TflApiPresentationEntitiesJourneyPlannerTimeAdjustment.md) |  | [optional] 
**Earlier** | [**TflApiPresentationEntitiesJourneyPlannerTimeAdjustment**](TflApiPresentationEntitiesJourneyPlannerTimeAdjustment.md) |  | [optional] 
**Later** | [**TflApiPresentationEntitiesJourneyPlannerTimeAdjustment**](TflApiPresentationEntitiesJourneyPlannerTimeAdjustment.md) |  | [optional] 
**Latest** | [**TflApiPresentationEntitiesJourneyPlannerTimeAdjustment**](TflApiPresentationEntitiesJourneyPlannerTimeAdjustment.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

