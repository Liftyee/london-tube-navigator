# IO.Swagger.Model.TflApiPresentationEntitiesLineRouteSection
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RouteId** | **int?** |  | [optional] 
**Direction** | **string** |  | [optional] 
**Destination** | **string** |  | [optional] 
**FromStation** | **string** |  | [optional] 
**ToStation** | **string** |  | [optional] 
**ServiceType** | **string** |  | [optional] 
**VehicleDestinationText** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

