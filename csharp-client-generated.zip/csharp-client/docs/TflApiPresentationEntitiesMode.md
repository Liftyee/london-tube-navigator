# IO.Swagger.Model.TflApiPresentationEntitiesMode
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsTflService** | **bool?** |  | [optional] 
**IsFarePaying** | **bool?** |  | [optional] 
**IsScheduledService** | **bool?** |  | [optional] 
**ModeName** | **string** |  | [optional] 
**MotType** | **string** |  | [optional] 
**Network** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

