# IO.Swagger.Model.TflApiPresentationEntitiesOrderedRoute
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**NaptanIds** | **List&lt;string&gt;** |  | [optional] 
**ServiceType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

