# IO.Swagger.Model.TflApiPresentationEntitiesPassengerFlow
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TimeSlice** | **string** | Time in 24hr format with 15 minute intervals e.g. 0500-0515, 0515-0530 etc. | [optional] 
**Value** | **int?** | Count of passenger flow towards a platform | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

