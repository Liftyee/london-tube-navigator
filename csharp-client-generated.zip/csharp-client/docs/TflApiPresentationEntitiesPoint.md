# IO.Swagger.Model.TflApiPresentationEntitiesPoint
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Lat** | **double?** | WGS84 latitude of the location. | [optional] 
**Lon** | **double?** | WGS84 longitude of the location. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

