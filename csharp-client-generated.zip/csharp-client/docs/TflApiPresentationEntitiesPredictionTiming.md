# IO.Swagger.Model.TflApiPresentationEntitiesPredictionTiming
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CountdownServerAdjustment** | **string** |  | [optional] 
**Source** | **DateTime?** |  | [optional] 
**Insert** | **DateTime?** |  | [optional] 
**Read** | **DateTime?** |  | [optional] 
**Sent** | **DateTime?** |  | [optional] 
**Received** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

