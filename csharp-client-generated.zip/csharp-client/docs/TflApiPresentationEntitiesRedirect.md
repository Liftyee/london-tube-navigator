# IO.Swagger.Model.TflApiPresentationEntitiesRedirect
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ShortUrl** | **string** |  | [optional] 
**LongUrl** | **string** |  | [optional] 
**Active** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

