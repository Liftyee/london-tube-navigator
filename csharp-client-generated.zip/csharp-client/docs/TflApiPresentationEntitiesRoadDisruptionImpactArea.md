# IO.Swagger.Model.TflApiPresentationEntitiesRoadDisruptionImpactArea
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | [optional] 
**RoadDisruptionId** | **string** |  | [optional] 
**Polygon** | [**SystemDataSpatialDbGeography**](SystemDataSpatialDbGeography.md) |  | [optional] 
**StartDate** | **DateTime?** |  | [optional] 
**EndDate** | **DateTime?** |  | [optional] 
**StartTime** | **string** |  | [optional] 
**EndTime** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

