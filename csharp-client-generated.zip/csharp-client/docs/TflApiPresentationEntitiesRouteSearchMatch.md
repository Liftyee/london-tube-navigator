# IO.Swagger.Model.TflApiPresentationEntitiesRouteSearchMatch
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LineId** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 
**LineName** | **string** |  | [optional] 
**LineRouteSection** | [**List&lt;TflApiPresentationEntitiesLineRouteSection&gt;**](TflApiPresentationEntitiesLineRouteSection.md) |  | [optional] 
**MatchedRouteSections** | [**List&lt;TflApiPresentationEntitiesMatchedRouteSections&gt;**](TflApiPresentationEntitiesMatchedRouteSections.md) |  | [optional] 
**MatchedStops** | [**List&lt;TflApiPresentationEntitiesMatchedStop&gt;**](TflApiPresentationEntitiesMatchedStop.md) |  | [optional] 
**Id** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Lat** | **double?** |  | [optional] 
**Lon** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

