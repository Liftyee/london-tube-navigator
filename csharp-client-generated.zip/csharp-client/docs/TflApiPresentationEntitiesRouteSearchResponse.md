# IO.Swagger.Model.TflApiPresentationEntitiesRouteSearchResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Input** | **string** |  | [optional] 
**SearchMatches** | [**List&lt;TflApiPresentationEntitiesRouteSearchMatch&gt;**](TflApiPresentationEntitiesRouteSearchMatch.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

