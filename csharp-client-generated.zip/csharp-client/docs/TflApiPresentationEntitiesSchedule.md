# IO.Swagger.Model.TflApiPresentationEntitiesSchedule
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**KnownJourneys** | [**List&lt;TflApiPresentationEntitiesKnownJourney&gt;**](TflApiPresentationEntitiesKnownJourney.md) |  | [optional] 
**FirstJourney** | [**TflApiPresentationEntitiesKnownJourney**](TflApiPresentationEntitiesKnownJourney.md) |  | [optional] 
**LastJourney** | [**TflApiPresentationEntitiesKnownJourney**](TflApiPresentationEntitiesKnownJourney.md) |  | [optional] 
**Periods** | [**List&lt;TflApiPresentationEntitiesPeriod&gt;**](TflApiPresentationEntitiesPeriod.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

