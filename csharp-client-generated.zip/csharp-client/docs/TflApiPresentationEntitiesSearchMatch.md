# IO.Swagger.Model.TflApiPresentationEntitiesSearchMatch
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Lat** | **double?** |  | [optional] 
**Lon** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

