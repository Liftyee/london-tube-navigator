# IO.Swagger.Model.TflApiPresentationEntitiesSearchResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Query** | **string** |  | [optional] 
**From** | **int?** |  | [optional] 
**Page** | **int?** |  | [optional] 
**PageSize** | **int?** |  | [optional] 
**Provider** | **string** |  | [optional] 
**Total** | **int?** |  | [optional] 
**Matches** | [**List&lt;TflApiPresentationEntitiesSearchMatch&gt;**](TflApiPresentationEntitiesSearchMatch.md) |  | [optional] 
**MaxScore** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

