# IO.Swagger.Model.TflApiPresentationEntitiesStopPointRouteSection
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NaptanId** | **string** |  | [optional] 
**LineId** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 
**ValidFrom** | **DateTime?** |  | [optional] 
**ValidTo** | **DateTime?** |  | [optional] 
**Direction** | **string** |  | [optional] 
**RouteSectionName** | **string** |  | [optional] 
**LineString** | **string** |  | [optional] 
**IsActive** | **bool?** |  | [optional] 
**ServiceType** | **string** |  | [optional] 
**VehicleDestinationText** | **string** |  | [optional] 
**DestinationName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

