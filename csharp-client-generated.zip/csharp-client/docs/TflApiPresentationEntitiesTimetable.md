# IO.Swagger.Model.TflApiPresentationEntitiesTimetable
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DepartureStopId** | **string** |  | [optional] 
**Routes** | [**List&lt;TflApiPresentationEntitiesTimetableRoute&gt;**](TflApiPresentationEntitiesTimetableRoute.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

