# IO.Swagger.Model.TflApiPresentationEntitiesTimetableRoute
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StationIntervals** | [**List&lt;TflApiPresentationEntitiesStationInterval&gt;**](TflApiPresentationEntitiesStationInterval.md) |  | [optional] 
**Schedules** | [**List&lt;TflApiPresentationEntitiesSchedule&gt;**](TflApiPresentationEntitiesSchedule.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

