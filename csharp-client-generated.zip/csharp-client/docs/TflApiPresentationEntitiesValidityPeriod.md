# IO.Swagger.Model.TflApiPresentationEntitiesValidityPeriod
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FromDate** | **DateTime?** | Gets or sets the start date. | [optional] 
**ToDate** | **DateTime?** | Gets or sets the end date. | [optional] 
**IsNow** | **bool?** | If true is a realtime status rather than planned or info | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

